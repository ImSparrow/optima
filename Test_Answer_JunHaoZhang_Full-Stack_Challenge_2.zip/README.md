Link to deployed Site: https://happy-kepler-14cbb3.netlify.app/

\To install the dependencies:

### `npm install`

To run the app:

### `npm start`

The initial page is the "All Users" page, which displays all the users and their number of posts\
You can click on the card to see all their posts, and click on the post to see the post thread itself\

Adding a post is very simple, just click on "Add Post" in the navbar, or if you are on mobile\
click on the hamburger menu top left of the screen and then click on "Add Post"\

Once on the "Add Post" page, you will have to fill in all the field for the post to be completed\

How the site determines new user's isnt based of their names, but off their emails.\
So you can have multiple names linked to one email.\
For every unqiue email there will be a unique user.\

If there is already a user, their post count will increase, and the new post will be added to thier\
post history\

You can also comment on any post, how it works is first you have to navigate to a post, once on a post\
you can post a reply by filling in the fields on the button of the screen, the reply will be linked to that post
